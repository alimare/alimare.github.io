package net.alimare.hedgehog.model;

import net.alimare.hedgehog.HedgeHogConstant;

/**
 *  Copyright 2011 Devin Shurtleff
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 *  This is the core class.  Initialize the system.  
 *  I suggest cache this object for re-use during application life cycle
 * 
 * 
 * 
 * @author dshurtleff
 */
public class DataRequest {
		
	private String file;
	private long version = HedgeHogConstant.CURRENT_VERSION;
	private boolean useInflator = true;
		
	public DataRequest() {
	}

	public String getFile() {
		return file;
	}

	public void setFile(String file) {
		this.file = file;
	}

	public long getVersion() {
		return version;
	}

	public void setVersion(long version) {
		this.version = version;
	}

	public boolean isUseInflator() {
		return useInflator;
	}

	public void setUseInflator(boolean useInflator) {
		this.useInflator = useInflator;
	}
		
}
