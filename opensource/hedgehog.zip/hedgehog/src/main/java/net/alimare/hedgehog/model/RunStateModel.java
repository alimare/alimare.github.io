package net.alimare.hedgehog.model;

/**
 *  Copyright 2011 Devin Shurtleff
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 *  This is the core class.  Initialize the system.  
 *  I suggest cache this object for re-use during application life cycle
 * 
 * 
 * 
 * @author dshurtleff
 */
public class RunStateModel
	implements Cloneable
{
	
	private long numberOfFilesCheckedInTotal;
	private long numberOfFilesCheckedOutTotal;
	private long numberOfFilesCheckedOutNow;

	public RunStateModel() {
	}
	
	public RunStateModel clone()
	{
		RunStateModel runStateModelClone = new RunStateModel();
		runStateModelClone.setNumberOfFilesCheckedInTotal(numberOfFilesCheckedInTotal);
		runStateModelClone.setNumberOfFilesCheckedOutNow(numberOfFilesCheckedOutNow);
		runStateModelClone.setNumberOfFilesCheckedOutTotal(numberOfFilesCheckedOutTotal);		
		return runStateModelClone;
	}

	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Total Checked in files: ").append(numberOfFilesCheckedInTotal).append("\n");
		sb.append("Total Checked Out files: ").append(numberOfFilesCheckedOutTotal).append("\n");
		sb.append("Total Checked Out now files: ").append(numberOfFilesCheckedOutNow).append("\n");		
		return sb.toString();
	}
	
	public long getNumberOfFilesCheckedInTotal() {
		return numberOfFilesCheckedInTotal;
	}

	public void setNumberOfFilesCheckedInTotal(long numberOfFilesCheckedInTotal) {
		this.numberOfFilesCheckedInTotal = numberOfFilesCheckedInTotal;
	}

	public long getNumberOfFilesCheckedOutTotal() {
		return numberOfFilesCheckedOutTotal;
	}

	public void setNumberOfFilesCheckedOutTotal(long numberOfFilesCheckedOutTotal) {
		this.numberOfFilesCheckedOutTotal = numberOfFilesCheckedOutTotal;
	}

	public long getNumberOfFilesCheckedOutNow() {
		return numberOfFilesCheckedOutNow;
	}

	public void setNumberOfFilesCheckedOutNow(long numberOfFilesCheckedOutNow) {
		this.numberOfFilesCheckedOutNow = numberOfFilesCheckedOutNow;
	}
		
}
