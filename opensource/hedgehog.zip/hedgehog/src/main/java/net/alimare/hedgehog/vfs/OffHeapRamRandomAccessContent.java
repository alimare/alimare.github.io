package net.alimare.hedgehog.vfs;

import java.io.IOException;
import java.io.InputStream;
import org.apache.commons.vfs2.RandomAccessContent;

/**
 *  Copyright 2011 Devin Shurtleff
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 *  This is the core class.  Initialize the system.  
 *  I suggest cache this object for re-use during application life cycle
 * 
 * 
 * 
 * @author dshurtleff
 */
public class OffHeapRamRandomAccessContent 
	extends Object
	implements RandomAccessContent
{

	@Override
	public long getFilePointer() throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public void seek(long l) throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public long length() throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public void close() throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public InputStream getInputStream() throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public void write(int b) throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public void write(byte[] b) throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public void write(byte[] b, int off, int len) throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public void writeBoolean(boolean v) throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public void writeByte(int v) throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public void writeShort(int v) throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public void writeChar(int v) throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public void writeInt(int v) throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public void writeLong(long v) throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public void writeFloat(float v) throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public void writeDouble(double v) throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public void writeBytes(String s) throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public void writeChars(String s) throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public void writeUTF(String s) throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public void readFully(byte[] b) throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public void readFully(byte[] b, int off, int len) throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public int skipBytes(int n) throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public boolean readBoolean() throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public byte readByte() throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public int readUnsignedByte() throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public short readShort() throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public int readUnsignedShort() throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public char readChar() throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public int readInt() throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public long readLong() throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public float readFloat() throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public double readDouble() throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public String readLine() throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public String readUTF() throws IOException {
		throw new UnsupportedOperationException("Not supported yet.");
	}
	
}
