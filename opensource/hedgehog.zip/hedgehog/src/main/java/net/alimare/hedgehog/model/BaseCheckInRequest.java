package net.alimare.hedgehog.model;

import java.io.InputStream;
import java.io.Serializable;

/**
 *  Copyright 2011 Devin Shurtleff
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 *  This is the core class.  Initialize the system.  
 *  I suggest cache this object for re-use during application life cycle
 * 
 * 
 * 
 * @author dshurtleff
 */
public abstract class BaseCheckInRequest
	implements Serializable
{
	private String baseDir="";
	private String fileName;
	private boolean request;
	private boolean compress = true;
	private boolean useDeflator = true;
		
	public BaseCheckInRequest() {
	}

	public abstract InputStream getProcessedStream();
	
	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public boolean isRequest() {
		return request;
	}

	public void setRequest(boolean request) {
		this.request = request;
	}

	public String getBaseDir() {
		return baseDir;
	}

	public void setBaseDir(String baseDir) {
		this.baseDir = baseDir;
	}

	public boolean isCompress() {
		return compress;
	}

	public void setCompress(boolean compress) {
		this.compress = compress;
	}

	public boolean isUseDeflator() {
		return useDeflator;
	}

	public void setUseDeflator(boolean useDeflator) {
		this.useDeflator = useDeflator;
	}
		
}
