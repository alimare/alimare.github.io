package net.alimare.hedgehog;

import com.thoughtworks.xstream.XStream;
import de.schlichtherle.truezip.file.TFileOutputStream;
import de.schlichtherle.truezip.nio.file.TPath;
import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.InflaterInputStream;
import net.alimare.hedgehog.exception.DataProcessingException;
import net.alimare.hedgehog.exception.DataSystemException;
import net.alimare.hedgehog.model.*;
import net.alimare.hedgehog.type.DeviceStatus;
import net.alimare.hedgehog.util.FileUtil;
import org.codehaus.jackson.map.ObjectMapper;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

/**
 *  Copyright 2011 Devin Shurtleff
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 *  This is the core class.  Initialize the system.  
 *  I suggest cache this object for re-use during application life cycle
 * 
 * 
 * 
 * @author dshurtleff
 */
public class DataManager {
	
	private static final long MAX_READ_LOCK_WAIT = 100;	
	private static final long MAX_WRITE_LOCK_WAIT = 50;	
	private static final int BUFFER_SIZE = 2048;
	private static final Logger log = Logger.getLogger(DataManager.class.getName());
	private static final String VERSION_MARKER = "V";
	private static final String SYNC_FILE = "sync_transaction.log";
	private static final String TEMP_EXT = ".TMP";
	private static final int MAX_WAIT_COUNT = 20;
	private static final String LOCK_EXTENSION = ".lock";
	
	
	private ConfigModel configModel;
	private final List<StorageDeviceModel> sharedStorageDevices = Collections.synchronizedList(new ArrayList<StorageDeviceModel>());
	private StorageDeviceModel localSorageDevice;
	private RunStateModel runStateModel = new RunStateModel();

	public DataManager(ConfigModel configModel) {
		//init the system
		reinit(configModel);
	}

	public final void reinit(ConfigModel configModel) {
		//disconnect the shared object
		this.configModel = configModel.clone();
		updateSharedStorageInfo();
		updateLocalStorageInfo();
		
		if (this.configModel.isSyncOnInit() &&
			this.configModel.isSyncSharedRoots())
		{
			syncSharedRoots();
		}
	}

	/**
	 *  Updates the storage free space. 
	 *  And availability.
	 */
	public void updateSharedStorageInfo() {
		
		synchronized (sharedStorageDevices) {
			sharedStorageDevices.clear();

			for (String sharedRoot : configModel.getSharedStorageRoots()) {
				StorageDeviceModel storageDeviceModel = new StorageDeviceModel();
				File root = new File(sharedRoot);
				boolean initDevice = true;
				if (root.exists() == false) {
					if (root.mkdirs() == false) {
						storageDeviceModel.setStatus(DeviceStatus.NotReady);
						initDevice = false;
					} else {
						storageDeviceModel.setStatus(DeviceStatus.Ready);
					}
				} else {
					storageDeviceModel.setStatus(DeviceStatus.Ready);
				}

				if (initDevice) {
					storageDeviceModel.setRootStoragePath(sharedRoot);
					storageDeviceModel.setInitialFreeSpace(root.getUsableSpace());
					storageDeviceModel.setUsedSpace(root.getTotalSpace() - root.getUsableSpace());
					storageDeviceModel.setTotalSpace(root.getTotalSpace());
					if (storageDeviceModel.getInitialFreeSpace() <= configModel.getSharedRootLowSpace()) {
						storageDeviceModel.setStatus(DeviceStatus.LowSpace);
					}
				}
				sharedStorageDevices.add(storageDeviceModel);
			}
		}
	}

	/**
	 *  Updates the storage free space. 
	 *  And availability.
	 */
	public void updateLocalStorageInfo() {
		localSorageDevice = new StorageDeviceModel();

		File root = new File(configModel.getLocalTempPath());
		boolean initDevice = true;
		if (root.exists() == false) {
			if (root.mkdirs() == false) {
				localSorageDevice.setStatus(DeviceStatus.NotReady);
				initDevice = false;
			} else {
				localSorageDevice.setStatus(DeviceStatus.Ready);
			}
		} else {
			localSorageDevice.setStatus(DeviceStatus.Ready);
		}

		if (initDevice) {
			localSorageDevice.setRootStoragePath(configModel.getLocalTempPath());			
			localSorageDevice.setInitialFreeSpace(root.getUsableSpace());
			localSorageDevice.setUsedSpace(root.getTotalSpace() - root.getUsableSpace());
			localSorageDevice.setTotalSpace(root.getTotalSpace());
			if (localSorageDevice.getInitialFreeSpace() <= configModel.getLocalRootLowSpace()) {
				localSorageDevice.setStatus(DeviceStatus.LowSpace);
			}
		}

	}

	public RunStateModel getRunStateModel()
	{		
		return runStateModel.clone();
	}
	
	public String getStatus(){
		StringBuilder sb = new StringBuilder();
		
		sb.append("Shared Devices").append("------------").append("\n");
		for (StorageDeviceModel shareDeviceModel : sharedStorageDevices)
		{
			sb.append(shareDeviceModel.toString()).append("\n");			
		}
		
		//local
		sb.append("Local Device").append("------------").append("\n");
		sb.append(localSorageDevice.toString()).append("\n");		
		return sb.toString();
	}
	
	public DataModel checkOut(DataRequest dataRequest) {
		DataModel dataModel = null;

		String fileName = dataRequest.getFile();
		if (dataRequest.getVersion() != HedgeHogConstant.CURRENT_VERSION)
		{			
			fileName = dataRequest.getFile() + VERSION_MARKER + dataRequest.getVersion();
		}
		StorageDeviceModel storageDeviceModel = findNextReadyDevice();		
		Path path = new TPath(storageDeviceModel.getRootStoragePath() + fileName);
		
		dataModel = new DataModel();
		try{
			
			if (path.toFile().exists()) {
				
				//check for locks
				boolean proceed = false;
				while (proceed == false) {
					proceed = true;
					for (StorageDeviceModel deviceModel : sharedStorageDevices) {
						String lockFileName = deviceModel.getRootStoragePath() + fileName + LOCK_EXTENSION;
						File lockFile = new File(lockFileName);
						if (lockFile.exists()) {
							//check time out
							long lastModifed = lockFile.lastModified();
							if (lastModifed != 0) {
								long timeOutTime = lastModifed + this.configModel.getLockTimeOut();
								if (System.currentTimeMillis() < timeOutTime) {
									proceed = false;
									try {
										Thread.sleep(MAX_READ_LOCK_WAIT);
									} catch (InterruptedException ie) {
									}
								}
							}
						}
					}
				}

				//copy to local root
				String localFileName = localSorageDevice.getRootStoragePath() + fileName;
				FileUtil.fastCopy(path, new FileOutputStream(new File(localFileName)));
				Path localPath = Paths.get(localFileName);

				dataModel.setInputStream(Files.newInputStream(localPath));
				dataModel.setVersion(dataRequest.getVersion());
				dataModel.setFilePointer(new File(localFileName));	
			}
		}
		catch (IOException ioe)
		{
			throw new DataProcessingException(ioe);
		}
		runStateModel.setNumberOfFilesCheckedOutTotal(runStateModel.getNumberOfFilesCheckedOutTotal() + 1);
		runStateModel.setNumberOfFilesCheckedOutNow(runStateModel.getNumberOfFilesCheckedOutNow() + 1);		
		return dataModel;
	}

	public DataModel directRead(DataRequest dataRequest) {
		DataModel dataModel = null;

		String fileName = dataRequest.getFile();
		if (dataRequest.getVersion() != HedgeHogConstant.CURRENT_VERSION)
		{			
			fileName = dataRequest.getFile() + VERSION_MARKER + dataRequest.getVersion();
		}
		StorageDeviceModel storageDeviceModel = findNextReadyDevice();		
		Path path = new TPath(storageDeviceModel.getRootStoragePath() + fileName);
		
		dataModel = new DataModel();
		if (path.toFile().exists()) {
			//check for locks
			boolean proceed = false;
			while (proceed == false) {
				proceed = true;
				for (StorageDeviceModel deviceModel : sharedStorageDevices) {
					String lockFileName = deviceModel.getRootStoragePath() + fileName + LOCK_EXTENSION;
					File lockFile = new File(lockFileName);
					if (lockFile.exists()) {
						//check time out
						long lastModifed = lockFile.lastModified();
						if (lastModifed != 0)
						{
							long timeOutTime = lastModifed + this.configModel.getLockTimeOut();	
							if (System.currentTimeMillis() < timeOutTime)
							{
								proceed = false;
								try {
									Thread.sleep(MAX_READ_LOCK_WAIT);
								} catch (InterruptedException ie) {
								}
							}
						}
					}
				}
			}

			dataModel = new DataModel();
			try {

				if (dataRequest.isUseInflator()) {
					dataModel.setInputStream(new InflaterInputStream(Files.newInputStream(path)));
				} else {
					dataModel.setInputStream(Files.newInputStream(path));
				}
				dataModel.setVersion(dataRequest.getVersion());


			} catch (IOException ioe) {
				throw new DataProcessingException(ioe);
			}
		}
		return dataModel;
	}
	
	private StorageDeviceModel findNextReadyDevice()
	{
		StorageDeviceModel storageDeviceModel = null;
		for (StorageDeviceModel sdm : sharedStorageDevices)
		{
			if (sdm.getStatus() == DeviceStatus.Ready ||
				sdm.getStatus() == DeviceStatus.LowSpace)
			{
				storageDeviceModel = sdm;
			}
		}
		if (storageDeviceModel == null){
			
			reinit(configModel);
			for (StorageDeviceModel sdm : sharedStorageDevices)
			{
				if (sdm.getStatus() == DeviceStatus.Ready ||
					sdm.getStatus() == DeviceStatus.LowSpace)
				{
					storageDeviceModel = sdm;
				}
			}			
			if (storageDeviceModel == null){
				throw new DataProcessingException("There's no shared device ready.");
			}
		}
		return storageDeviceModel;
	}
	
	public boolean checkIn(BaseCheckInRequest checkInRequest) {
		boolean success = false;

		try {
			
			//check for locks
			boolean proceed = false;
			while (proceed == false) {
				proceed = true;
				for (StorageDeviceModel deviceModel : sharedStorageDevices) {
					String checkInFileName = deviceModel.getRootStoragePath() + checkInRequest.getBaseDir() + checkInRequest.getFileName();
					String lockFileName = checkInFileName + LOCK_EXTENSION;
					File lockFile = new File(lockFileName);
					if (lockFile.exists()) {
						//check time out

						long lastModifed = lockFile.lastModified();
						if (lastModifed != 0) {
							long timeOutTime = lastModifed + this.configModel.getLockTimeOut();
							if (System.currentTimeMillis() < timeOutTime) {
								proceed = false;
								try {
									Thread.sleep(MAX_WRITE_LOCK_WAIT);
								} catch (InterruptedException ie) {
								}
							}
						}
					}
				}
			}				

			//write locks	
			//Note: is write lock only use to reduce the collisons
			for (StorageDeviceModel deviceModel : sharedStorageDevices) {
				String checkInFileName = deviceModel.getRootStoragePath() + checkInRequest.getBaseDir() + checkInRequest.getFileName();								
				String lockFileName = checkInFileName + LOCK_EXTENSION;
				File lockFile = new File(lockFileName);	
				try {
					boolean createdLock = lockFile.createNewFile();
					if (!createdLock)
					{
						lockFile.setLastModified(System.currentTimeMillis());						
					}
				} catch (Exception e) {
					//ignore 
				}				
			}
					
			//write in
			InputStream inputStream = null;
			if (checkInRequest instanceof CheckInObject) {
				CheckInObject checkInObject = (CheckInObject) checkInRequest;
				if (checkInObject.isLargeObject() == false) {
					inputStream = checkInRequest.getProcessedStream();
				}
			} else {
				inputStream = checkInRequest.getProcessedStream();
			}

			//set up output		
			boolean createSyncFile = false;
			List<OutputStream> outs = new ArrayList<>();
			List<String> originalFileNames = new ArrayList<>();
			boolean corruptionProtection = true;
			for (StorageDeviceModel deviceModel : sharedStorageDevices) {
				try {
					if (checkInRequest.getBaseDir() != null && "".equals(checkInRequest.getBaseDir().trim())) {
						File baseDir = new File(checkInRequest.getBaseDir());
						baseDir.mkdirs();
					}

					
					String actualFileName = deviceModel.getRootStoragePath() + checkInRequest.getBaseDir() + checkInRequest.getFileName();
					String extension = TEMP_EXT;
					String lowerAcualFileName = actualFileName.toLowerCase();
					for(HedgeHogConstant.ArchiveExtensions archiveExtensions : HedgeHogConstant.ArchiveExtensions.values())
					{
						if (lowerAcualFileName.contains(archiveExtensions.getExtension()))
						{
							extension = "";
							corruptionProtection = false;
							break;
						}
					}
					
					originalFileNames.add(actualFileName);					
					if (checkInRequest.isCompress()) {
						if (checkInRequest.isUseDeflator()) {
							outs.add(new BufferedOutputStream(new DeflaterOutputStream(new TFileOutputStream(actualFileName + extension))));
						} else {
							outs.add(new BufferedOutputStream(new TFileOutputStream(actualFileName + extension)));
						}
					} else {
						if (checkInRequest.isUseDeflator()) {
							outs.add(new BufferedOutputStream(new DeflaterOutputStream(new FileOutputStream(actualFileName + extension))));
						} else {
							outs.add(new BufferedOutputStream(new FileOutputStream(actualFileName + extension)));
						}
					}
				} catch (Exception e) {
					deviceModel.setStatus(DeviceStatus.NotReady);
					createSyncFile = true;
				}
			}

			boolean writeSuccessful = false;
			try {
				if (checkInRequest instanceof CheckInObject) {
					CheckInObject checkInObject = (CheckInObject) checkInRequest;
					XStream xStream = new XStream();
					ObjectMapper objectMapper = FileUtil.getJsonMapper();
					CsvBeanWriter writer = null;
					for (OutputStream out : outs) {
						if (checkInObject.isUseCsv()) {
							writer = new CsvBeanWriter(new OutputStreamWriter(out), CsvPreference.STANDARD_PREFERENCE);
							writer.write(checkInObject.getSerialableObject());
						} else if (checkInObject.isUseJSON()) {
							objectMapper.writeValue(out, checkInObject.getSerialableObject());
						} else {
							//Use XML
							xStream.toXML(checkInObject.getSerialableObject(), out);
						}
					}
				} else {
					int num = -1;
					byte[] b = new byte[BUFFER_SIZE];
					while ((num = inputStream.read(b)) > -1) {
						for (OutputStream out : outs) {
							out.write(b, 0, num);
						}
					}
					for (OutputStream out : outs) {
						out.flush();
					}
				}
				writeSuccessful = true;
			} catch (Exception e) {
				//Some files could have been writing to some roots.
				//What can I do at this point...one of the drive might been offline
				throw new DataSystemException("Failed to check in file. Some of the shared devices may be missing a file.\n Highly recommend trying to re-check in file....as one of the roots may have gone offline.", e);
			} finally {
				if (inputStream != null) {
					try {
						inputStream.close();
					} catch (IOException e) {
					}
				}

				for (OutputStream out : outs) {
					try {
						out.close();
					} catch (Exception e) {
					}
				}
				
				if (corruptionProtection) {
					//Rename files (Commit Changes)
					if (writeSuccessful) {
						for (String origFile : originalFileNames) {
							
							int waitCount = 0;
							while (Paths.get(origFile + TEMP_EXT).toFile().exists() == false && waitCount < MAX_WAIT_COUNT)
							{
								try
								{
									Thread.sleep(50);									
								}
								catch (Exception e)
								{									
								}								
								waitCount++;
							}							
							
							Files.move(Paths.get(origFile + TEMP_EXT), Paths.get(origFile), StandardCopyOption.REPLACE_EXISTING);
						}
					} else {
						//delete tmp files (RollBack)
						for (String origFile : originalFileNames) {
							Files.deleteIfExists(Paths.get(origFile + TEMP_EXT));
						}
					}
				}
			}
			//keep a sycn log if config for syncing
			//put log in the good root
			if (createSyncFile
					&& writeSuccessful
					&& configModel.isSyncSharedRoots()
					&& sharedStorageDevices.size() > 1) {
				//find the good root (if any)
				for (StorageDeviceModel deviceModel : sharedStorageDevices) {
					if (deviceModel.getStatus() == DeviceStatus.Ready
							|| deviceModel.getStatus() == DeviceStatus.LowSpace) {
						Path checkFilePath = Paths.get(deviceModel.getRootStoragePath() + checkInRequest.getBaseDir() + checkInRequest.getFileName());

						SyncRecordModel syncRecordModel = new SyncRecordModel();
						syncRecordModel.setOriginRoot(deviceModel.getRootStoragePath());
						syncRecordModel.setUpdateFilePath(checkFilePath.toString());
						syncRecordModel.setLastModifiedTime(checkFilePath.toFile().lastModified());

						//look for sync file if exists append
						Path path = Paths.get(deviceModel.getRootStoragePath() + SYNC_FILE);
						BufferedWriter writer = null;
						try {
							if (path.toFile().exists()) {
								writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(path.toFile(), true)));
							} else {
								writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(path.toFile())));
							}
							try {
								writer.write(syncRecordModel.writeRecord());
								writer.newLine();
							} catch (Exception ex) {
								throw new DataSystemException("Failed to write Sync Record.", ex);
							}
						} catch (IOException ioe) {
							throw new DataSystemException("Failed to create Sync File.", ioe);

						} finally {
							if (writer != null) {
								try {
									writer.close();
								} catch (IOException e) {
								}
							}
						}
						break;
					}
				}
			}
			success = true;

			runStateModel.setNumberOfFilesCheckedInTotal(runStateModel.getNumberOfFilesCheckedInTotal() + 1);
		} catch (Exception ex) {
			throw new DataSystemException(ex);
		} finally {
			//clear Locks
			for (StorageDeviceModel deviceModel : sharedStorageDevices) {
				String checkInFileName = deviceModel.getRootStoragePath() + checkInRequest.getBaseDir() + checkInRequest.getFileName();
				String lockFileName = checkInFileName + LOCK_EXTENSION;
				File lockFile = new File(lockFileName);	
				try {
					if (lockFile.exists())
					{
						lockFile.delete();
					}
				} catch (Exception e) {
					//ignore 
				}				
			}
		}
		
		return success;
	}

	public void syncSharedRoots()
	{
		//check each root
		for (StorageDeviceModel deviceModel : sharedStorageDevices)
		{
			//look for sync file
			Path path = Paths.get(deviceModel.getRootStoragePath() + SYNC_FILE);
			if (path.toFile().exists())
			{
				List<String> syncRecords = new ArrayList<>();
				try {
					//read and process file
					syncRecords = Files.readAllLines(path, Charset.defaultCharset());					
				} catch (IOException ex) {
					log.log(Level.SEVERE, "Sync file: {0} is corrupt.  Try deleting the file...and manually syncing.", path.toString());
					throw new DataSystemException("Sync File is corrupt: " + path.toString(), ex);
				}
				
				for (String record : syncRecords)
				{
					SyncRecordModel syncRecordModel = SyncRecordModel.parseRecord(record);
					
					for (StorageDeviceModel storageDeviceModel : sharedStorageDevices)
					{
						if (storageDeviceModel.getRootStoragePath().equals(deviceModel.getRootStoragePath()) == false)
						{
							if (DeviceStatus.Ready == storageDeviceModel.getStatus() ||
								DeviceStatus.LowSpace == storageDeviceModel.getStatus())		
							{
								Path inputPath = Paths.get(syncRecordModel.getUpdateFilePath());
								
								if (syncRecordModel.isRemoveRequest())
								{
									try
									{
										Files.deleteIfExists(Paths.get(storageDeviceModel.getRootStoragePath(), syncRecordModel.getFilePathMinusRoot()));									
									} catch (Exception ex) {
										log.log(Level.SEVERE, "Unable to Delete {0}", storageDeviceModel.getRootStoragePath() + syncRecordModel.getFilePathMinusRoot());
										throw new DataSystemException(storageDeviceModel.getRootStoragePath() + syncRecordModel.getFilePathMinusRoot() +  " was not synced to: " + storageDeviceModel.getRootStoragePath(), ex);
									}										
								}
								else
								{
									try {
										FileUtil.fastCopy(inputPath, new FileOutputStream(storageDeviceModel.getRootStoragePath() + inputPath.getFileName()));

									} catch (Exception ex) {
										log.log(Level.SEVERE, "Unable to copy:{0} to {1}{2}", new Object[]{inputPath.toString(), storageDeviceModel.getRootStoragePath(), inputPath.getFileName()});
										throw new DataSystemException(inputPath + " was not synced to: " + storageDeviceModel.getRootStoragePath(), ex);
									}									
								}
							}
						}
					}
				}
				try {
					Files.delete(path);
				} catch (IOException ex) {
					//unable to delete
					log.log(Level.SEVERE, "Unable to delete Sync record: {0}", path);
					throw new DataSystemException("Unable to delete Sync record: "+ path, ex);
				}
			}
		}
	}
		
	public void deletePath(String pathString)
	{
		for (StorageDeviceModel deviceModel : sharedStorageDevices) {
			pathString = pathString.replace("\\", "/");
            pathString = pathString.replace(deviceModel.getRootStoragePath(), "");			
			
			Path path = Paths.get(deviceModel.getRootStoragePath() + pathString);
			try {
				if (path.toFile().isDirectory()) {
					for (File childFile : path.toFile().listFiles()) {
						deletePath(childFile.getPath());
					}
					Files.deleteIfExists(path);
				} else {
					Files.deleteIfExists(path);
				}
			} catch (Exception e) {
				log.log(Level.SEVERE, "Unable to delete file (Delete Request...storage devices may be out of sync.) Path: {0}", path);

				//create a delete sync records on the good drives
				//find the good root (if any)
				for (StorageDeviceModel deviceModelSync : sharedStorageDevices) {
					if (deviceModelSync.getStatus() == DeviceStatus.Ready
							|| deviceModelSync.getStatus() == DeviceStatus.LowSpace) {
						Path checkFilePath = Paths.get(deviceModelSync.getRootStoragePath() + pathString);

						SyncRecordModel syncRecordModel = new SyncRecordModel();
						syncRecordModel.setOriginRoot(deviceModelSync.getRootStoragePath());
						syncRecordModel.setUpdateFilePath(checkFilePath.toString());
						syncRecordModel.setLastModifiedTime(checkFilePath.toFile().lastModified());
						syncRecordModel.setFilePathMinusRoot(pathString);

						//look for sync file if exists append
						Path syncPath = Paths.get(deviceModelSync.getRootStoragePath() + SYNC_FILE);
						BufferedWriter writer = null;
						try {
							if (syncPath.toFile().exists()) {
								writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(syncPath.toFile(), true)));
							} else {
								writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(syncPath.toFile())));
							}
							try {
								writer.write(syncRecordModel.writeRecord());
								writer.newLine();
							} catch (Exception ex) {
								throw new DataSystemException("Unable to delete all files request.  Note: some files may have been delete.  See logs for more information. Failed to write Sync Record.", ex);
							}
						} catch (IOException ioe) {
							throw new DataSystemException(" Unable to delete all files request.  Note: some files may have been delete.  See logs for more information. Failed to create Sync File.", ioe);

						} finally {
							if (writer != null) {
								try {
									writer.close();
								} catch (IOException ex) {
								}
							}
						}
						break;
					}
				}
			}
		}

	}
	
	
	/**
	 * Copy all files from one root to the others
	 * @param goodRoot
	 * @param syncRoots 
	 */
	public static void forceFullSync(String goodRoot, String... syncRoots) throws IOException
	{		
     final Path source = Paths.get(goodRoot);
	 final String targetRoots[] = syncRoots;
	 
     Files.walkFileTree(source, EnumSet.of(FileVisitOption.FOLLOW_LINKS), Integer.MAX_VALUE,
         new SimpleFileVisitor<Path>() {
             @Override
             public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs)
                 throws IOException
             {
				 for (String targetRoot : targetRoots) {
					 Path targetPath = Paths.get(targetRoot);
					 
					 Path targetdir = targetPath.resolve(source.relativize(dir));
					 try {
						 Files.copy(dir, targetdir);
					 } catch (FileAlreadyExistsException e) {
						 if (!Files.isDirectory(targetdir)) {
							 throw e;
						 }
					 }
				 }				 
                 return FileVisitResult.CONTINUE;
             }
             @Override
             public FileVisitResult visitFile(Path file, BasicFileAttributes attrs)
                 throws IOException
             {
				 for (String targetRoot : targetRoots) {
					 Path targetPath = Paths.get(targetRoot);
					 Files.copy(file, targetPath.resolve(source.relativize(file)), StandardCopyOption.REPLACE_EXISTING);
				 }
                 return FileVisitResult.CONTINUE;
             }
         });		
	}
	
	public static ConfigModel loadConfig(InputStream in) {
		ConfigModel configModel = new ConfigModel();

		Properties props = new Properties();
		try {					
			props.load(in);
			
			//TODO: convert props to model
			configModel.setLocalRootLowSpace(Long.parseLong(props.getProperty(ConfigModel.PROP_LOW_SPACE_LOCAL, "" + ConfigModel.LOCAL_LOW_SPACE_INDICATOR)));
			configModel.setSharedRootLowSpace(Long.parseLong(props.getProperty(ConfigModel.PROP_LOW_SPACE_SHARED, "" + ConfigModel.LOW_SPACE_INDICATOR)));
			configModel.setLocalTempPath(props.getProperty(ConfigModel.PROP_LOW_SPACE_SHARED, "tmp:/"));
			configModel.setSyncOnInit(Boolean.parseBoolean(props.getProperty(ConfigModel.PROP_SYNC_INIT, "true")));
			configModel.setSyncSharedRoots(Boolean.parseBoolean(props.getProperty(ConfigModel.PROP_SYNC_STORAGE, "true")));
			
			String shareStorage = props.getProperty(ConfigModel.PROP_SHARED_STORAGE);
			
			String shareStorages[] = shareStorage.split(",");
			configModel.getSharedStorageRoots().addAll(Arrays.asList(shareStorages));
			
		} catch (IOException ex) {
			log.log(Level.SEVERE, "Failed to load properties.", ex);
		}

		return configModel;
	}

	public static ErrorModel saveFile(File inputFile, String... outputFiles) {
		try {
			return saveFile(new FileInputStream(inputFile), outputFiles);
		} catch (FileNotFoundException ex) {
			throw new DataProcessingException("Input File doesn't exist.", ex);
		}
	}

	/**
	 * Attempt to write the input to multiple out put
	 * If one or more of the output a
	 * @param in
	 * @param outputFiles
	 * @return ErrorModel containing the errors
	 */
	public static ErrorModel saveFile(InputStream in, String... outputFiles) {
		ErrorModel errorModel = new ErrorModel();
		try {
			//try to init each output 
			//skipping output that work
			List<OutputStream> outs = new ArrayList<>();
			for (String outFile : outputFiles) {
				try {
					File file = new File(outFile);
					outs.add(new FileOutputStream(file));
				} catch (Exception e) {
					log.log(Level.WARNING, "Error output file: {0}", e.getMessage());
					errorModel.getErrors().add("Unable to create output file: " + outFile);
				}
			}

			if (outs.isEmpty() == false) {
				saveToMulipleDevices(in, outs);
			}
		} catch (Exception e) {
		}
		return errorModel;
	}

	public static void saveToMulipleDevices(InputStream in, List<OutputStream> outs) {
		try {
			int num = -1;
			byte[] b = new byte[BUFFER_SIZE];
			while ((num = in.read(b)) > -1) {
				for (OutputStream out : outs) {
					out.write(b, 0, num);
				}
			}
			for (OutputStream out : outs) {
				out.flush();
			}
		} catch (IOException io) {
			throw new DataProcessingException("InputFailed failed to store: ", io);
		} finally {
			try {
				in.close();
			} catch (IOException io) {
				log.log(Level.SEVERE, "Error output file: {0}", io.getMessage());
			}
			try {
				for (OutputStream out : outs) {
					out.close();
				}
			} catch (IOException io) {
				log.log(Level.SEVERE, "Error output file: {0}", io.getMessage());
			}
		}

	}
	
	public static void syncAllArchives()
	{
		
	}

	public static void syncArchive(String archive)
	{
		//umount
	}

	
}
