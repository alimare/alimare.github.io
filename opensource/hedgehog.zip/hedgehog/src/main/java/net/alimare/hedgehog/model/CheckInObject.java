package net.alimare.hedgehog.model;

import com.thoughtworks.xstream.XStream;
import java.io.ByteArrayInputStream;
import java.io.InputStream;

/**
 *  Copyright 2011 Devin Shurtleff
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 *  This is the core class.  Initialize the system.  
 *  I suggest cache this object for re-use during application life cycle
 * 
 * 
 * 
 * @author dshurtleff
 */
public class CheckInObject extends BaseCheckInRequest{

	private Object serialableObject;
	private boolean largeObject = true;
	private boolean useCsv = false;
	private boolean useJSON = false;

	public CheckInObject() {
	}

	/**
	 * This is best for small objects 
	 * for large it's best to write the object directly
	 * @return 
	 */
	@Override	
	public InputStream getProcessedStream() {
		XStream xstream = new XStream();			
		return new ByteArrayInputStream(xstream.toXML(serialableObject).getBytes());		
	}

	public Object getSerialableObject() {
		return serialableObject;
	}

	public void setSerialableObject(Object serialableObject) {
		this.serialableObject = serialableObject;
	}

	public boolean isLargeObject() {
		return largeObject;
	}

	public void setLargeObject(boolean largeObject) {
		this.largeObject = largeObject;
	}

	public boolean isUseCsv() {
		return useCsv;
	}

	public void setUseCsv(boolean useCsv) {
		this.useCsv = useCsv;
	}

	public boolean isUseJSON() {
		return useJSON;
	}

	public void setUseJSON(boolean useJSON) {
		this.useJSON = useJSON;
	}

}
