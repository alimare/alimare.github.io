package net.alimare.hedgehog.model;

import java.io.Serializable;

/**
 *  Copyright 2011 Devin Shurtleff
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 * 
 * 
 * @author dshurtleff
 */
public class SyncRecordModel 
	implements Serializable
{
	private static final String SEPERATOR = "\t";
	
	private String originRoot;
	private String updateFilePath;
	private long lastModifiedTime; 
	private boolean removeRequest;
	private String filePathMinusRoot = "stub-root";
	
	public SyncRecordModel() {
	}

	public static SyncRecordModel parseRecord(String record)
	{
		SyncRecordModel syncRecordModel = new SyncRecordModel();
		String[] data = record.split(SEPERATOR);
		syncRecordModel.setOriginRoot(data[0]);
		syncRecordModel.setUpdateFilePath(data[1]);
		syncRecordModel.setLastModifiedTime(Long.parseLong(data[2]));
		syncRecordModel.setRemoveRequest(Boolean.parseBoolean(data[3]));
		syncRecordModel.setFilePathMinusRoot(data[4]);
		return syncRecordModel;		
	}
	
	public String writeRecord()
	{
		StringBuilder sb = new StringBuilder();
		sb.append(originRoot).append(SEPERATOR);
		sb.append(updateFilePath).append(SEPERATOR);
		sb.append(lastModifiedTime).append(SEPERATOR);
		sb.append(removeRequest).append(SEPERATOR);
		sb.append(filePathMinusRoot);
		return sb.toString();
	}

	public String getOriginRoot() {
		return originRoot;
	}

	public void setOriginRoot(String originRoot) {
		this.originRoot = originRoot;
	}

	public String getUpdateFilePath() {
		return updateFilePath;
	}

	public void setUpdateFilePath(String updateFilePath) {
		this.updateFilePath = updateFilePath;
	}

	public long getLastModifiedTime() {
		return lastModifiedTime;
	}

	public void setLastModifiedTime(long lastModifiedTime) {
		this.lastModifiedTime = lastModifiedTime;
	}

	public boolean isRemoveRequest() {
		return removeRequest;
	}

	public void setRemoveRequest(boolean removeRequest) {
		this.removeRequest = removeRequest;
	}

	public String getFilePathMinusRoot() {
		return filePathMinusRoot;
	}

	public void setFilePathMinusRoot(String filePathMinusRoot) {
		this.filePathMinusRoot = filePathMinusRoot;
	}
	
}
