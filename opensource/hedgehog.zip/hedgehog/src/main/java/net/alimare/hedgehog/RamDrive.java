package net.alimare.hedgehog;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.InflaterInputStream;
import net.alimare.hedgehog.exception.DataSystemException;
import org.apache.commons.vfs2.*;

/**
 * This is a heap ram drive (Note: the actual is shared) 
 * So clean must be done to clean up the files
 * This also may not represent all files in memory...since file it sees are based on the root
 * @author dshurtleff
 */
public class RamDrive 
{
	private static final Logger log = Logger.getLogger("net.alimare.hedgehog");
	
	private FileSystemManager fsManager; 
	private String rootDir;	
	private ConcurrentLinkedQueue<FileObject> fileObjects = new ConcurrentLinkedQueue<>();
	
	public RamDrive(String rootDir) {
		init(rootDir, true, false);		
	}
	
	public RamDrive(String rootDir, boolean restoreRoot) {
		init(rootDir, restoreRoot, false);
	}	
	
	public RamDrive(String rootDir, boolean restoreRoot, boolean freshDrive) {
		init(rootDir, restoreRoot, freshDrive);
	}	
	
	private void init(String rootDir, boolean restoreRoot, boolean freshDrive)
	{
		this.rootDir = rootDir;
		try {
			fsManager = VFS.getManager();
			
			if (freshDrive)
			{			
				restoreRoot(rootDir);
				cleanUpDrive();
			}
			else if (restoreRoot)
			{
				restoreRoot(rootDir);
			}
			
		} catch (FileSystemException ex) {
			throw new DataSystemException(ex);
		}
			
	}
	
	public void restoreRoot(String directory)
	{
		try {
			FileObject rootFile = fsManager.resolveFile("ram:" + directory);
			addFileObjects(rootFile.getChildren());
			
		} catch (FileSystemException ex) {
			Logger.getLogger(RamDrive.class.getName()).log(Level.SEVERE, null, ex);
		}
	}
	
	private void addFileObjects(FileObject[] files)
	{
		for (FileObject fileObject : files)
		{
			try {
				if (FileType.FOLDER.equals(fileObject.getType()))
				{
					addFileObjects(fileObject.getChildren());
				}
				else
				{
					fileObjects.add(fileObject);					
				}
			} catch (FileSystemException ex) {
				log.log(Level.SEVERE, "Unable delete file: {0}", fileObject.toString());
			}
		}			
	}
	
	public InputStream getInput(String filename)
	{
		return getInput(filename, true);
	}
	
	public InputStream getInput(String filename, boolean compressed)
	{
		InputStream in = null;
		
		try
		{
			FileObject fileObject = fsManager.resolveFile("ram:" + rootDir + "/" +  filename);
			if (compressed)
			{
				in = new InflaterInputStream(fileObject.getContent().getInputStream());			
			}
			else
			{
				in = fileObject.getContent().getInputStream();			
			}
		}
		catch (Exception e)
		{
			throw new DataSystemException(e);
		}
		
		return in;		
	}
	
	public OutputStream getOutput(String filename)
	{
		return getOutput(filename, true);
	}	
	
	public OutputStream getOutput(String filename, boolean compressed)
	{
		OutputStream out = null;
		try
		{
			FileObject fileObject = fsManager.resolveFile("ram:" + rootDir + "/" +  filename);
			if (compressed)
			{
				out = new DeflaterOutputStream(fileObject.getContent().getOutputStream());			
			}
			else
			{
				out = fileObject.getContent().getOutputStream();			
			}
			fileObjects.add(fileObject);			
		}
		catch (Exception e)
		{
			throw new DataSystemException(e);
		}		
		return out;
	}
	
	public void deleteFile(String filename)
	{
		try {
			FileObject fileObject = fsManager.resolveFile("ram:" + rootDir + "/" +  filename);
			if (FileType.FILE.equals(fileObject.getType()))
			{
				fileObject.delete();
			}
			else if (FileType.FOLDER.equals(fileObject.getType()))
			{
				cleanUpDrive(fileObject.getChildren());
			}
		} catch (FileSystemException ex) {
			Logger.getLogger(RamDrive.class.getName()).log(Level.SEVERE, null, ex);
		}
		
	}
	
	public List<String> listFiles()
	{
		List<String> filePaths = new ArrayList<>();
		for (FileObject fileObject : fileObjects)
		{
			filePaths.add(fileObject.getName().getPath());			
		}		
		return filePaths;
	}
	
	public long getUsedSpace()
	{
		long usedSpace = 0;
		
		//They should all be files
		for (FileObject fileObject : fileObjects)
		{
			try {
				if (FileType.FILE.equals(fileObject.getType()))
				{
					usedSpace = usedSpace + fileObject.getContent().getSize();
				}
			} catch (FileSystemException ex) {
				log.log(Level.WARNING, "Unable to get size of file.");
			}
		}
		return usedSpace;
	}
	
	public void cleanUpDrive()
	{
		try {
			FileObject rootFile = fsManager.resolveFile("ram:" + rootDir);
			cleanUpDrive(rootFile.getChildren());
		} catch (FileSystemException ex) {
			Logger.getLogger(RamDrive.class.getName()).log(Level.SEVERE, null, ex);
		}
		fileObjects.clear();
	}

	private void cleanUpDrive(FileObject[] files)
	{
		for (FileObject fileObject : files)
		{
			try {
				if (FileType.FOLDER.equals(fileObject.getType()))
				{
					cleanUpDrive(fileObject.getChildren());
				}
				else
				{
					fileObject.delete();
				}
			} catch (FileSystemException ex) {
				log.log(Level.SEVERE, "Unable delete file: {0}", fileObject.toString());
			}
		}		
		
	}
	
	
	public ConcurrentLinkedQueue<FileObject> getFileObjects() {
		return fileObjects;
	}
	
}
