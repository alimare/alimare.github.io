package net.alimare.hedgehog.util;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.mapper.MapperWrapper;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import net.alimare.hedgehog.exception.DataProcessingException;
import org.codehaus.jackson.map.ObjectMapper;

/**
 *  Copyright 2011 Devin Shurtleff
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 * @author dshurtleff
 */
public class FileUtil {

	private static ObjectMapper objectMapper;
	
	public static void fastCopy(Path source, OutputStream out){
		try{
			Files.copy(source, out);
		} catch (IOException ex) {
			throw new DataProcessingException(ex);
		} finally {
			try {
				out.close();
			} catch (IOException ex) {
				//Ignore; nothing to do
			}
		}
	}
	
	public static XStream getFlexableReaderXStream()
	{
		XStream xstream = new XStream()
		{
			@Override
			protected MapperWrapper wrapMapper(MapperWrapper next)
			{
				return new MapperWrapper(next)
				{
					@Override
					public boolean shouldSerializeMember(Class definedIn,
														 String fieldName)
					{
						if (definedIn == Object.class)
						{
							return false;
						}
						return super.shouldSerializeMember(definedIn, fieldName);
					}
				};
			}
		};
		return xstream;
	}
	
	public static ObjectMapper getJsonMapper()
	{
		if (objectMapper == null)
		{
			objectMapper = new ObjectMapper();			
		}
		return objectMapper;		
	}
	
}
