package net.alimare.hedgehog.model;

import java.util.ArrayList;
import java.util.List;

/**
 *  Copyright 2011 Devin Shurtleff
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 *  This is the core class.  Initialize the system.  
 *  I suggest cache this object for re-use during application life cycle
 * 
 * 
 * 
 * @author dshurtleff
 */
public class ConfigModel implements Cloneable{
    
	public static final String PROP_SHARED_STORAGE = "shared.storage";
	public static final String PROP_LOCAL_STORAGE = "local.storage";
	public static final String PROP_SYNC_STORAGE = "sync.storage";
	public static final String PROP_SYNC_INIT = "sync.init";	
	public static final String PROP_LOW_SPACE_SHARED = "low.space";
	public static final String PROP_LOW_SPACE_LOCAL = "low.space.local";
	
	
	public static final long LOW_SPACE_INDICATOR = 100000000;
	public static final long LOCAL_LOW_SPACE_INDICATOR = 50000000;		
	
	//Increase if file are large or there a delay writing to the storage
	public static final long LOCK_TIME_OUT = 5000;
	
	private List<String> sharedStorageRoots = new ArrayList<>();
	private String localTempPath = "tmp:/";
	private long sharedRootLowSpace = LOW_SPACE_INDICATOR;
	private long localRootLowSpace = LOCAL_LOW_SPACE_INDICATOR;
	private boolean syncSharedRoots = true;
	private boolean syncOnInit = true;
	private long lockTimeOut = LOCK_TIME_OUT;

	public ConfigModel() {
	}
	
	@Override
	public ConfigModel clone()
	{
		ConfigModel configModel = new ConfigModel();
		configModel.getSharedStorageRoots().addAll(this.sharedStorageRoots);
		configModel.setLocalTempPath(this.localTempPath);		
		return configModel;
	}

	public List<String> getSharedStorageRoots() {
		return sharedStorageRoots;
	}

	public void setSharedStorageRoots(List<String> sharedStorageRoots) {
		this.sharedStorageRoots = sharedStorageRoots;
	}

	public String getLocalTempPath() {
		return localTempPath;
	}

	public void setLocalTempPath(String localTempPath) {
		this.localTempPath = localTempPath;
	}

	public long getSharedRootLowSpace() {
		return sharedRootLowSpace;
	}

	public void setSharedRootLowSpace(long sharedRootLowSpace) {
		this.sharedRootLowSpace = sharedRootLowSpace;
	}

	public long getLocalRootLowSpace() {
		return localRootLowSpace;
	}

	public void setLocalRootLowSpace(long localRootLowSpace) {
		this.localRootLowSpace = localRootLowSpace;
	}

	public boolean isSyncSharedRoots() {
		return syncSharedRoots;
	}

	public void setSyncSharedRoots(boolean syncSharedRoots) {
		this.syncSharedRoots = syncSharedRoots;
	}

	public boolean isSyncOnInit() {
		return syncOnInit;
	}

	public void setSyncOnInit(boolean syncOnInit) {
		this.syncOnInit = syncOnInit;
	}

	public long getLockTimeOut() {
		return lockTimeOut;
	}

	public void setLockTimeOut(long lockTimeOut) {
		this.lockTimeOut = lockTimeOut;
	}
	
}
