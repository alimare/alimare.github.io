package net.alimare.hedgehog.model;

import net.alimare.hedgehog.type.DeviceStatus;

/**
 *  Copyright 2011 Devin Shurtleff
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 *  This is the core class.  Initialize the system.  
 *  I suggest cache this object for re-use during application life cycle
 * 
 * 
 * 
 * @author dshurtleff
 */
public class StorageDeviceModel {
	
	private String rootStoragePath;
	private long initialFreeSpace;
	private long usedSpace;
	private long totalSpace;
	private DeviceStatus status;

	public StorageDeviceModel() {
	}
	
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Root: ").append(rootStoragePath).append("\n");
		sb.append("Status: ").append(status).append("\n");
		sb.append("Freespace: ").append(initialFreeSpace).append("\n");
		sb.append("UsedSpace: ").append(usedSpace).append("\n");
		sb.append("TotalSpace: ").append(totalSpace).append("\n");
		return sb.toString();
	}

	public String getRootStoragePath() {
		return rootStoragePath;
	}

	public void setRootStoragePath(String rootStoragePath) {
		this.rootStoragePath = rootStoragePath;
	}

	public long getInitialFreeSpace() {
		return initialFreeSpace;
	}

	public void setInitialFreeSpace(long initialFreeSpace) {
		this.initialFreeSpace = initialFreeSpace;
	}

	public long getUsedSpace() {
		return usedSpace;
	}

	public void setUsedSpace(long usedSpace) {
		this.usedSpace = usedSpace;
	}

	public DeviceStatus getStatus() {
		return status;
	}

	public void setStatus(DeviceStatus status) {
		this.status = status;
	}

	public long getTotalSpace() {
		return totalSpace;
	}

	public void setTotalSpace(long totalSpace) {
		this.totalSpace = totalSpace;
	}

}
