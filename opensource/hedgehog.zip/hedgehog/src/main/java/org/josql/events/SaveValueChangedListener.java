package org.josql.events;

public interface SaveValueChangedListener
{

    public void saveValueChanged (SaveValueChangedEvent ev);

}