package org.josql.events;

public interface BindVariableChangedListener
{

    public void bindVariableChanged (BindVariableChangedEvent ev);

}