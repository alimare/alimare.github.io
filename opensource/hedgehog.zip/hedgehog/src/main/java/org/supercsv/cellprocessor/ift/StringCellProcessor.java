package org.supercsv.cellprocessor.ift;

public interface StringCellProcessor extends CellProcessor {
}
