package org.supercsv.cellprocessor.ift;

public interface BoolCellProcessor extends CellProcessor {
}
