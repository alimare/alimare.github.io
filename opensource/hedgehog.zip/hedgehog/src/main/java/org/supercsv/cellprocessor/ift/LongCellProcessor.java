package org.supercsv.cellprocessor.ift;

public interface LongCellProcessor extends CellProcessor {
}
