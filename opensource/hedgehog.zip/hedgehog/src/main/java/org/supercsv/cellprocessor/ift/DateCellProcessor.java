package org.supercsv.cellprocessor.ift;

public interface DateCellProcessor extends CellProcessor {
}
