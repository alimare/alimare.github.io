/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package net.alimare.hedgehog;

import java.util.ArrayList;
import java.util.List;
import net.alimare.hedgehog.model.CheckInObject;

/**
 *
 * @author dshurtleff
 */
public class CheckInTest 
	implements Runnable
{
	int id;
	DataManager dataManager;

	public CheckInTest(int id, DataManager dataManager) {
		this.id = id;
		this.dataManager = dataManager;
	}

	@Override
	public void run() {
		
		for (int i = 0; i < 10; i++) {
			
			List<String> dataList = new ArrayList<>();
			for (int j=0; j<1000000; j++)
			{
				dataList.add("Test");
				dataList.add("Speed");
				dataList.add("A");
			}

			CheckInObject checkInObject = new CheckInObject();
			checkInObject.setSerialableObject(dataList);
			checkInObject.setFileName(id + "-test" + i + ".json");
			checkInObject.setLargeObject(true);
			checkInObject.setUseJSON(true);

			dataManager.checkIn(checkInObject);
		}
		
		System.out.println("Done with group: " + id);
		
	}
	
}
