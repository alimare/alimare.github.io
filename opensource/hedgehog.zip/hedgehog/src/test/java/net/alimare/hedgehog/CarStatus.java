package net.alimare.hedgehog;

public class CarStatus {

	private String status;
	private boolean active;
	private int numberOfWheels;
	private long engineHours;
	
	public CarStatus() {
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public int getNumberOfWheels() {
		return numberOfWheels;
	}

	public void setNumberOfWheels(int numberOfWheels) {
		this.numberOfWheels = numberOfWheels;
	}

	public long getEngineHours() {
		return engineHours;
	}

	public void setEngineHours(long engineHours) {
		this.engineHours = engineHours;
	}
	
}
