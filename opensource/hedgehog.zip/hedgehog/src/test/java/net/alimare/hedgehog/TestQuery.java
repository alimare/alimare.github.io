package net.alimare.hedgehog;

import com.googlecode.cqengine.CQEngine;
import com.googlecode.cqengine.IndexedCollection;
import com.googlecode.cqengine.index.navigable.NavigableIndex;
import com.googlecode.cqengine.query.Query;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import junit.framework.TestCase;
import static com.googlecode.cqengine.query.QueryFactory.*;

/**
 *
 * @author dshurtleff
 */
public class TestQuery 
	extends TestCase
{
	
//	static final Logger log = Logger.getLogger(new Object() {		
//	}.getClass().getEnclosingClass().getName());
//	
//	public void testClassName()
//	{
//		System.out.println(new Object(){}.getClass().getEnclosingClass().getName());
//	}
	
	
	public void testQueryName()
	{
		List<CarModel> carList = new ArrayList<>();
		
		CarModel carModel = new CarModel();
		
		carModel.setName("Test");
		carModel.setModel("Ford");
		carModel.setOdometer(new BigDecimal("678"));
		carModel.setType("car");
		
		CarStatus carStatus = new CarStatus();
		carStatus.setActive(true);
		carStatus.setEngineHours(546);
		carStatus.setNumberOfWheels(4);
		carStatus.setStatus("Test Stats");
		
		carList.add(carModel);
		
		carModel = new CarModel();
		
		carModel.setName("Can");
		carModel.setModel("Chevy");
		carModel.setOdometer(new BigDecimal("63"));
		carModel.setType("car");
		
		carStatus = new CarStatus();
		carStatus.setActive(true);
		carStatus.setEngineHours(546);
		carStatus.setNumberOfWheels(4);
		carStatus.setStatus("Test Stats");
		
		carList.add(carModel);

		
		carModel = new CarModel();
		
		carModel.setName("Ram");
		carModel.setModel("Dodge");
		carModel.setOdometer(new BigDecimal("5"));
		carModel.setType("truck");
		
		carStatus = new CarStatus();
		carStatus.setActive(true);
		carStatus.setEngineHours(654);
		carStatus.setNumberOfWheels(4);
		carStatus.setStatus("Test Stats");
		
		carList.add(carModel);
		
		IndexedCollection<CarModel> cars = CQEngine.copyFrom(carList);
	
		
		cars.addIndex(NavigableIndex.onAttribute(CarModel.CAR_NAME));
		
		 
		
		Query<CarModel> query1 = endsWith(CarModel.CAR_NAME, "R");
		for (CarModel car : cars.retrieve(query1)) {
			System.out.println(car.getName());
		}		
		
		
		
	}
	
}
