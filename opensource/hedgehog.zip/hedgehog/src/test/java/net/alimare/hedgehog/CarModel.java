package net.alimare.hedgehog;

import com.googlecode.cqengine.attribute.Attribute;
import com.googlecode.cqengine.attribute.SimpleAttribute;
import java.math.BigDecimal;

public class CarModel {
	
	
	private String name;
	private String type;
	private String model;
	private BigDecimal odometer;
	private CarStatus carStatus;
	
	public CarModel() {
	}

    public static final Attribute<CarModel, String> CAR_NAME = new SimpleAttribute<CarModel, String>("name") {
		@Override
        public String getValue(CarModel car) { return car.getName(); }
    };	
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public BigDecimal getOdometer() {
		return odometer;
	}

	public void setOdometer(BigDecimal odometer) {
		this.odometer = odometer;
	}

	public CarStatus getCarStatus() {
		return carStatus;
	}

	public void setCarStatus(CarStatus carStatus) {
		this.carStatus = carStatus;
	}
	
}
