package net.alimare.hedgehog;

import com.thoughtworks.xstream.XStream;
import de.schlichtherle.truezip.file.TFileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.List;
import java.util.concurrent.Callable;

/**
 *
 * @author dshurtleff
 */
public class ReadMilesTask 
	implements Callable<TestLocationModel>
{
	private String filePath;
	
	
	@Override
	public TestLocationModel call() throws Exception {
		TestLocationModel testLocationModel = new TestLocationModel();
		
		XStream xstream = new XStream();
		List<TestLocationModel> readOne;
		InputStream in = null;
		try {
			in = new TFileInputStream(filePath);
			readOne = (List<TestLocationModel>) xstream.fromXML(in);
			for (TestLocationModel testLocationModelLocal : readOne)
			{			
				testLocationModel.setMiles(testLocationModel.getMiles().add(testLocationModelLocal.getMiles()));
				testLocationModel.setFuel(testLocationModel.getFuel().add(testLocationModelLocal.getFuel()));
			}				
		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		}
		finally
		{
			if (in != null)
			{
				try
				{
					in.close();					
				}
				catch (Exception e)					
				{					
				}
			}
			}			
		
		
		return testLocationModel;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	
	
}
