package net.alimare.hedgehog;

import com.thoughtworks.xstream.XStream;
import de.schlichtherle.truezip.file.TFile;
import de.schlichtherle.truezip.file.TFileInputStream;
import de.schlichtherle.truezip.file.TFileOutputStream;
import de.schlichtherle.truezip.fs.FsOutputOption;
import de.schlichtherle.truezip.fs.FsSyncOption;
import de.schlichtherle.truezip.util.BitField;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.math.BigDecimal;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinTask;
import java.util.concurrent.TimeUnit;
import java.util.logging.ConsoleHandler;
import java.util.logging.ErrorManager;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.InflaterInputStream;
import java.util.zip.ZipOutputStream;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import net.alimare.hedgehog.model.CheckInObject;
import net.alimare.hedgehog.model.ConfigModel;
import net.alimare.hedgehog.model.DataModel;
import net.alimare.hedgehog.model.DataRequest;
import net.alimare.hedgehog.model.ErrorModel;
import net.alimare.hedgehog.util.FileUtil;
import org.apache.commons.vfs2.FileObject;
import org.apache.commons.vfs2.FileSystemException;
import org.apache.commons.vfs2.FileSystemManager;
import org.apache.commons.vfs2.VFS;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.supercsv.io.CsvListReader;
import org.supercsv.io.CsvListWriter;
import org.supercsv.prefs.CsvPreference;

/**
 * Unit test for simple App.
 */
public class AppTest
		extends TestCase {

	

	
	/**
	 * Create the test case
	 *
	 * @param testName name of the test case
	 */
	public AppTest(String testName) {
		super(testName);
	}

	/**
	 * @return the suite of tests being tested
	 */
	public static Test suite() {
		return new TestSuite(AppTest.class);
	}

	public void dtestStub()
	{		
	}
	
	public void dtestApp() {
		try {
			FileUtil.fastCopy(Paths.get("N:/netbeans7-options.zip"), new FileOutputStream("e:/test.zip"));
		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		}
	}

	public void dtestMultiSave() {
		ErrorModel errorModel = DataManager.saveFile(new File("N:/netbeans7-options.zip"), "e:/mtest1.zip", "c:/test/mtest1.zip");
		System.out.println("Errors: \n" + errorModel.toString());
	}

	public void dtestInit() {
		ConfigModel configModel = new ConfigModel();
		configModel.getSharedStorageRoots().add("E:/");
		configModel.getSharedStorageRoots().add("N:/");

		DataManager dataManager = new DataManager(configModel);

		System.out.println(dataManager.getStatus());

	}

	public void dtestCsvWrite() {
		CsvListWriter writer = null;
		try {
			List<String> testString = new ArrayList<>();
			writer = new CsvListWriter(new FileWriter("E:/test.csv"), CsvPreference.STANDARD_PREFERENCE);

			testString.add("Test");
			testString.add("Speed");
			testString.add("A");
			writer.write(testString);




		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (writer != null) {
				try {
					writer.close();
				} catch (IOException ex) {
					ex.printStackTrace();
				}
			}
		}
	}

	public void dtestCsvRead() {
		CsvListReader reader = null;
		try {
			reader = new CsvListReader(new FileReader("E:/test.csv"), CsvPreference.STANDARD_PREFERENCE);
			List<String> data = reader.read();
			for (String dataEntry : data) {
				System.out.println(dataEntry);
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException ex) {
					ex.printStackTrace();
				}
			}
		}
	}

	public void dtestCheckIn() {
		ConfigModel configModel = new ConfigModel();
		configModel.getSharedStorageRoots().add("F:/testhhog/");
		configModel.getSharedStorageRoots().add("N:/development/testhhog/");

		DataManager dataManager = new DataManager(configModel);

		//check in
		List<String> dataList = new ArrayList<>();
		dataList.add("Test");
		dataList.add("Speed");
		dataList.add("A");
		CheckInObject checkInObject = new CheckInObject();
		checkInObject.setSerialableObject(dataList);
		checkInObject.setFileName("testSmallList.xml");
		checkInObject.setLargeObject(true);

		dataManager.checkIn(checkInObject);

	}

	public void dtestCheckOut() {
		ConfigModel configModel = new ConfigModel();
		configModel.getSharedStorageRoots().add("E://testhhog/");
		configModel.getSharedStorageRoots().add("N:/development/testhhog/");

		DataManager dataManager = new DataManager(configModel);

		DataRequest dataRequest = new DataRequest();
		dataRequest.setFile("testSmallList.xml");

		DataModel dataModel = dataManager.checkOut(dataRequest);

		try (BufferedReader bin = dataModel.getReader()) {
			String line = bin.readLine();
			while (line != null) {
				System.out.println("Line: " + line);
				line = bin.readLine();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dataModel.finish();
		}

	}

	public void dtestDirectRead() {
		ConfigModel configModel = new ConfigModel();
		configModel.getSharedStorageRoots().add("E://testhhog/");
		configModel.getSharedStorageRoots().add("N:/development/testhhog/");

		DataManager dataManager = new DataManager(configModel);

		DataRequest dataRequest = new DataRequest();
		dataRequest.setFile("testSmallList.xml");

		DataModel dataModel = dataManager.directRead(dataRequest);

		try (BufferedReader bin = dataModel.getReader()) {
			String line = bin.readLine();
			while (line != null) {
				System.out.println("Line: " + line);
				line = bin.readLine();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dataModel.finish();
		}
	}

	public void dtestVFSRamDrive() {
		CsvListWriter writer = null;
		try {
			FileSystemManager fsManager = VFS.getManager();

			FileObject txtFile = fsManager.resolveFile("ram:/test.txt");
			txtFile.createFile();
			OutputStream out = txtFile.getContent().getOutputStream();

			List<String> testString = new ArrayList<>();
			writer = new CsvListWriter(new OutputStreamWriter(out), CsvPreference.STANDARD_PREFERENCE);

			testString.add("Test");
			testString.add("Speed");
			testString.add("A");
			writer.write(testString);

			writer.close();

			System.out.println("Url: " + txtFile.getURL());

			CsvListReader reader = null;
			reader = new CsvListReader(new InputStreamReader(txtFile.getContent().getInputStream()), CsvPreference.STANDARD_PREFERENCE);
			List<String> data = reader.read();
			for (String dataEntry : data) {
				System.out.println(dataEntry);
			}

			reader.close();


		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	public void dtestLog() {
		Logger log2 = Logger.getGlobal();
		log2.setLevel(Level.FINE);

		Logger log = Logger.getLogger("test");
		ConsoleHandler handler = new ConsoleHandler();
		handler.setLevel(Level.FINEST);

		log.setLevel(Level.FINE);
		log.addHandler(handler);


		log.fine("test1 fine");


		log2.fine("test2 fine");

		log2.info("test2 info");
	}

	public void dtestMassReadWrite() {
//		//write data
//		System.out.println("Test Write");
//		long startTime = System.currentTimeMillis();
		XStream xstream = new XStream();
//		Random rnd = new Random(System.currentTimeMillis());
//		for (int i =0; i<1000; i++)
//		{
//			List<TestLocationModel> models = new ArrayList<>();
//			for (int j=0; j<2500; j++)
//			{
//				TestLocationModel testLocationModel = new TestLocationModel();
//				testLocationModel.setFuel(new BigDecimal(rnd.nextDouble()*300));
//				testLocationModel.setMiles(new BigDecimal(rnd.nextDouble()*100));
//				testLocationModel.setLatitude(new BigDecimal(rnd.nextDouble()*70));
//				testLocationModel.setLongitude(new BigDecimal(rnd.nextDouble()*-120));
//				models.add(testLocationModel);
//			}
//			OutputStream out = null;
//			try {
//				out = new TFileOutputStream("e:/test/arch_"+i+".zip/data.xml");
//				
//				xstream.toXML(models, out);
//			} catch (FileNotFoundException ex) {
//				ex.printStackTrace();
//			}
//			finally
//			{
//				if (out != null)
//				{
//					try 
//					{
//						out.close();
//					}
//					catch (Exception e)
//					{
//						
//					}
//				}
//			}
//		}
//		System.out.println("Time to Complete: " + (System.currentTimeMillis() - startTime));
//		
//		
//		//read and diplay stats
//		
//		startTime = System.currentTimeMillis();
//		InputStream in = null;
//		try {
//			in = new TFileInputStream("e:/test/arch_0.zip/data.xml");
//			List<TestLocationModel> readOne = (List<TestLocationModel>) xstream.fromXML(in);
//			BigDecimal total = BigDecimal.ZERO;
//			for (TestLocationModel testLocationModel : readOne)
//			{
//				total= total.add(testLocationModel.getMiles());
//			}
//			System.out.println("Total Miles: " + total.toPlainString());
//			
//		} catch (FileNotFoundException ex) {
//			ex.printStackTrace();
//		}
//		finally
//		{
//			if (in != null)
//			{
//				try
//				{
//					in.close();					
//				}
//				catch (Exception e)					
//				{					
//				}
//			}
//		}
//		
//		System.out.println("Time to Read One: " + (System.currentTimeMillis() - startTime));

		long startTime = System.currentTimeMillis();
		ForkJoinPool mainPool = new ForkJoinPool();

		File testDir = new File("e:/test");
		BigDecimal total = BigDecimal.ZERO;
		BigDecimal totalFuel = BigDecimal.ZERO;
		InputStream in = null;
		List<ForkJoinTask<TestLocationModel>> joinPools = new ArrayList<>();
		for (File file : testDir.listFiles()) {
			String fileName = file + "/data.xml";
			ReadMilesTask readMilesTask = new ReadMilesTask();
			readMilesTask.setFilePath(fileName);
			joinPools.add(mainPool.submit(readMilesTask));
		}

		for (ForkJoinTask task : joinPools) {
			try {
				TestLocationModel testLocationModel = (TestLocationModel) task.get();
				total = total.add(testLocationModel.getMiles());
				totalFuel = totalFuel.add(testLocationModel.getFuel());
			} catch (InterruptedException ex) {
				ex.printStackTrace();
			} catch (ExecutionException ex) {
				ex.printStackTrace();
			}
		}

		System.out.println("Total Miles: " + total.toPlainString());
		System.out.println("Total Fuel: " + totalFuel.toPlainString());
		System.out.println("Time to Read all: " + (System.currentTimeMillis() - startTime));
		mainPool.shutdownNow();
	}

	public void dtestSync() {
		ConfigModel configModel = new ConfigModel();
		configModel.getSharedStorageRoots().add("E://testhhog/");
		configModel.getSharedStorageRoots().add("F://testhog/");
		configModel.setSyncSharedRoots(true);
		configModel.setSyncOnInit(true);

		DataManager dataManager = new DataManager(configModel);

//		//check in
//		List<String> dataList = new ArrayList<>();
//		dataList.add("Test");
//		dataList.add("Speed");
//		dataList.add("A");		
//		CheckInObject checkInObject = new CheckInObject();
//		checkInObject.setSerialableObject(dataList);
//		checkInObject.setFileName("testSmallList.xml");
//		checkInObject.setLargeObject(true);
//				
//		dataManager.checkIn(checkInObject);		
//		try {
//			System.out.println("Pausing....");
//			Thread.sleep(5000);
//		} catch (InterruptedException ex) {
//			ex.printStackTrace();
//		}
//		System.out.println("Resume");
//		
//		checkInObject = new CheckInObject();
//		checkInObject.setSerialableObject(dataList);
//		checkInObject.setFileName("testSmallList2.xml");
//		checkInObject.setLargeObject(true);		
//		dataManager.checkIn(checkInObject);
//		
	}

	public void dtestZipSync() {

		ConfigModel configModel = new ConfigModel();
		configModel.getSharedStorageRoots().add("E://testhhog/");
		//configModel.getSharedStorageRoots().add("N:/development/testhhog/");

		DataManager dataManager = new DataManager(configModel);

		//check in
		List<String> dataList = new ArrayList<>();
		dataList.add("Test");
		dataList.add("Speed");
		dataList.add("A");
		CheckInObject checkInObject = new CheckInObject();
		checkInObject.setSerialableObject(dataList);
		checkInObject.setFileName("testSynce.zip/testSmallList.xml");
		checkInObject.setLargeObject(true);

		dataManager.checkIn(checkInObject);




		try {

			TFile.sync(BitField.of(FsSyncOption.CLEAR_CACHE));
			//Thread.sleep(20000);
		} catch (Exception ex) {
			Logger.getLogger(AppTest.class.getName()).log(Level.SEVERE, null, ex);
		}


	}

	public void dtestCompressedRamDrive() {
		CsvListWriter writer = null;
		try {
			FileSystemManager fsManager = VFS.getManager();

			FileObject txtFile = fsManager.resolveFile("ram:/test.txt");
			txtFile.createFile();
			OutputStream out = txtFile.getContent().getOutputStream();

			List<String> testString = new ArrayList<>();
			writer = new CsvListWriter(new OutputStreamWriter(new DeflaterOutputStream(out)), CsvPreference.STANDARD_PREFERENCE);

			for (int i = 0; i < 100000; i++) {
				testString.add("Test");
				testString.add("Speed");
				testString.add("A");
			}
			writer.write(testString);

			writer.close();

			System.out.println("Url: " + txtFile.getURL());
			System.out.println("size: " + txtFile.getContent().getSize());

//			CsvListReader reader = null;
//			reader = new CsvListReader(new InputStreamReader(new InflaterInputStream(txtFile.getContent().getInputStream())), CsvPreference.STANDARD_PREFERENCE);
//			List<String> data = reader.read();
//			for (String dataEntry : data)
//			{
//				System.out.println(dataEntry);
//			}
//			
//			reader.close();
			//Thread.sleep(10000);

		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	public void dtestDeflator() {

		ConfigModel configModel = new ConfigModel();
		configModel.getSharedStorageRoots().add("F://testhhog/");
		//configModel.getSharedStorageRoots().add("N:/development/testhhog/");

		DataManager dataManager = new DataManager(configModel);

		//check in
		List<String> dataList = new ArrayList<>();
		for (int i = 0; i < 100000; i++) {
			dataList.add("Test");
			dataList.add("Speed");
			dataList.add("A");
		}
		CheckInObject checkInObject = new CheckInObject();
		checkInObject.setUseJSON(true);
		checkInObject.setCompress(true);
		checkInObject.setUseDeflator(false);
		checkInObject.setSerialableObject(dataList);
		//checkInObject.setBaseDir("testSync/");
		checkInObject.setFileName("testSmallList.json");
		checkInObject.setLargeObject(true);

		dataManager.checkIn(checkInObject);
	}

	public void dtestInflator() {

		ConfigModel configModel = new ConfigModel();
		configModel.getSharedStorageRoots().add("F://testhhog/");
		//configModel.getSharedStorageRoots().add("N:/development/testhhog/");

		DataManager dataManager = new DataManager(configModel);

		DataRequest dataRequest = new DataRequest();
		dataRequest.setUseInflator(true);
		dataRequest.setFile("testSmallList.json");

		DataModel dataModel = dataManager.directRead(dataRequest);

		ObjectMapper objectMapper = FileUtil.getJsonMapper();
		
		try {			
			List<String> data = objectMapper.readValue(dataModel.getInputStream(), new TypeReference<List<String>>(){});
			for (String dataItem : data)
			{
				System.out.println(dataItem);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dataModel.finish();
		}		
		
		
//		try (BufferedReader bin = dataModel.getReader()) {			
//			String line = bin.readLine();
//			while (line != null) {
//				System.out.println(line);
//				line = bin.readLine();
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		} finally {
//			dataModel.finish();
//		}

	}
	
	public void dtestLocks()
	{
		ConfigModel configModel = new ConfigModel();
		//configModel.getSharedStorageRoots().add("E://testhhog/");
		configModel.getSharedStorageRoots().add("F:/testhhog/");

		DataManager dataManager = new DataManager(configModel);

				//check in
		List<String> dataList = new ArrayList<>();
		dataList.add("Test");
		dataList.add("Speed");
		dataList.add("A");
		CheckInObject checkInObject = new CheckInObject();
		checkInObject.setSerialableObject(dataList);
		checkInObject.setFileName("testSmallList3.xml");
		checkInObject.setLargeObject(true);
		checkInObject.setUseJSON(true);
		
				
		for (int i =0; i<100; i++)
		{
			dataManager.checkIn(checkInObject);		
		}
	}
	
	
	public void dtestFileContention()
	{
		ConfigModel configModel = new ConfigModel();
		//configModel.getSharedStorageRoots().add("E://testhhog/");
		configModel.getSharedStorageRoots().add("F:/testhhog/test/");

		DataManager dataManager = new DataManager(configModel);

				//check in
//		List<String> dataList = new ArrayList<>();
//		dataList.add("Test");
//		dataList.add("Speed");
//		dataList.add("A");
//		checkInObject = new CheckInObject();
//		checkInObject.setSerialableObject(dataList);
//		checkInObject.setFileName("testSmallList4.json");
//		checkInObject.setLargeObject(true);
//		checkInObject.setUseJSON(true);
		
		//checkInObject.setCompress(false);
		//checkInObject.setUseDeflator(false);
						
		ForkJoinPool pool = new ForkJoinPool();
		
		for (int i=0; i<10; i++)
		{
			pool.submit(new CheckInTest(i, dataManager));
		}
		
		pool.shutdown();
		try {
			pool.awaitTermination(10, TimeUnit.HOURS);
		} catch (InterruptedException ex) {
			Logger.getLogger(AppTest.class.getName()).log(Level.SEVERE, null, ex);
		}
		
	}
	
}
