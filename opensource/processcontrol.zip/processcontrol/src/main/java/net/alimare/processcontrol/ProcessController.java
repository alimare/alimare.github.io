package net.alimare.processcontrol;

import net.alimare.processcontrol.model.JobRequest;
import net.alimare.processcontrol.model.Node;

/**
 *
 * @author dshurtleff
 */
public class ProcessController {
	
	public ProcessController() {
	}
	
	
	public void runJob(JobRequest jobRequest)
	{
		//base on job type find the least buzy node of the prefered job type
		
		
		
		
	}
	
	/**
	 * Find the current controller node
	 * @return 
	 */
	public Node findControllerNode()
	{
		Node controlNode = null;
		
		//if it can't find the job controller set set the current node as controller
		
		
		
		return controlNode;
	}
	
}
