package net.alimare.processcontrol.types;

/**
 * 
 * @author dshurtleff
 */
public abstract class AbstractJobType {
	
	public abstract String jobType();
	
	
}
