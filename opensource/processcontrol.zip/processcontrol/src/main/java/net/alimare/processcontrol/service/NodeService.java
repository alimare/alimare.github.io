package net.alimare.processcontrol.service;

import javax.ejb.Local;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import net.alimare.processcontrol.model.JobRequest;
import net.alimare.processcontrol.model.Node;
import net.alimare.processcontrol.storage.Storage;
import net.alimare.processcontrol.types.NodeStatus;

/**
 *
 * @author dshurtleff
 */
@Singleton
@Local
public class NodeService 
{
	public static final String JEE_JNDI_NAME = "java:/module/NodeService";
		
	private static Node node = new Node();	
	private static Storage storage;
	
	@Schedule(second="30")
	public void checkin()
	{
		if (storage != null)
		{
			node.refreshAll();
			storage.registerNode(node);			
		}
	}

	public void setNodeStorage(Storage storage)
	{
		synchronized(storage)
		{
			NodeService.storage = storage;
		}
	}
	
	public NodeStatus getNodeStatus()
	{
		return node.getNodeStatus();
	}
	
	public void submitJobToNode(JobRequest jobRequest)
	{
		node.submitJobToRun(jobRequest);
	}
	
}
