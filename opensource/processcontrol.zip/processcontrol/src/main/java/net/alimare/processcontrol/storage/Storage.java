package net.alimare.processcontrol.storage;

import java.util.List;
import net.alimare.processcontrol.model.Node;

/**
 *
 * @author dshurtleff
 */
public interface Storage
{	
	
	public boolean registerNode(Node node);
	
	public void disableNode(long nodeId);
	
	public void markNodeAsOffline(long nodeId);
	
	public List<Node> getAllNodes();
	
	public List<Node> getAllNodes(String instanceId);
	
	public void setNodeAsMaster(Node node);
	
	public void findMasterNode();
	
}
