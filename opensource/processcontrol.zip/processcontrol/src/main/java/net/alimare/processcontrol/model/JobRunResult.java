package net.alimare.processcontrol.model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author dshurtleff
 */
public class JobRunResult {

	private List<String> errors = new ArrayList<>();
	private StringBuilder results = new StringBuilder();

	public JobRunResult() {
	}

	public List<String> getErrors() {
		return errors;
	}

	public void setErrors(List<String> errors) {
		this.errors = errors;
	}

	public StringBuilder getResults() {
		return results;
	}

	public void setResults(StringBuilder results) {
		this.results = results;
	}

}
