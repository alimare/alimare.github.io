package net.alimare.processcontrol.model;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author dshurtleff
 */
public class JobContext {
	
	private Map<String, Object> jobProperties = new HashMap<>();

	public JobContext() {
	}

	public Map<String, Object> getJobProperties() {
		return jobProperties;
	}

	public void setJobProperties(Map<String, Object> jobProperties) {
		this.jobProperties = jobProperties;
	}
		
}
