package net.alimare.processcontrol;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.alimare.processcontrol.model.JobRequest;
import net.alimare.processcontrol.model.Node;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

/**
 *
 * @author dshurtleff
 */
public abstract class BuildJobRequest 
	implements Job
{

	@Override
	public void execute(JobExecutionContext jec) throws JobExecutionException {
		JobRequest jobRequest = buildRequest();
		ProcessController processController = new ProcessController();
		Node masterNode = processController.findControllerNode();
		
		String restUrl =  "http://" + masterNode.getNodeIp() + 
				          System.getProperty("net.alimare.processcontrol.server.port") + "/" + 
				          System.getProperty("net.alimare.processcontrol.server.restUrl") + 
				          "/JobSubmit.action?SumbitJobToController&";
		
		//Convert Job Request to params
		StringBuilder params = new StringBuilder();
		
		
		InputStream in = null;
		try {
			URLConnection connection = new URL(restUrl + params).openConnection();
			in = connection.getInputStream();
			
			BufferedReader bin = new BufferedReader(new InputStreamReader(in));
			
			
			
		} catch (IOException  ex) {
			Logger.getLogger(BuildJobRequest.class.getName()).log(Level.SEVERE, null, ex);
		}
		finally 
		{
			if (in == null)
			{
				try {
					in.close();
				} catch (IOException ex) {
					Logger.getLogger(BuildJobRequest.class.getName()).log(Level.SEVERE, null, ex);
				}
			}
		}
		
		
	}
	
	protected abstract JobRequest buildRequest();
	
}
