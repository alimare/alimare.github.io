package net.alimare.processcontrol.model;

import java.io.Serializable;
import net.alimare.processcontrol.types.AbstractJobType;

/**
 *
 * @author dshurtleff
 */
public class JobRequest 
	implements Serializable
{
	private String jobName;
	private AbstractJobType jobType;
	private String jobClass;
	private JobContext jobContext;
	
	public JobRequest() {
	}

	public AbstractJobType getJobType() {
		return jobType;
	}

	public void setJobType(AbstractJobType jobType) {
		this.jobType = jobType;
	}

	public String getJobClass() {
		return jobClass;
	}

	public void setJobClass(String jobClass) {
		this.jobClass = jobClass;
	}

	public JobContext getJobContext() {
		return jobContext;
	}

	public void setJobContext(JobContext jobContext) {
		this.jobContext = jobContext;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

}
