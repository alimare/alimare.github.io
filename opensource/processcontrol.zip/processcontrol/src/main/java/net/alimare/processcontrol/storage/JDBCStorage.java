package net.alimare.processcontrol.storage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import net.alimare.processcontrol.model.Node;
import net.alimare.processcontrol.util.ProcessControlConstant;

/**
 *
 * @author dshurtleff
 */
public class JDBCStorage 
	implements Storage
{
	
	private String driverName;
	private String connectionURL;
	private String userName;
	private	String password;
	
	private String jiniName;
	
	private Connection connection;
	private boolean closeConnection;
	
	public JDBCStorage(String jiniName) throws SQLException {
		InitialContext context;
		try {
			context = new InitialContext();
			DataSource datasource = (DataSource) context.lookup(jiniName);
			connection = datasource.getConnection();
		} catch (NamingException ex) {
			Logger.getLogger(ProcessControlConstant.LOGGER_NAME).log(Level.SEVERE, null, ex);
		}
	}

	public JDBCStorage(String driverName, String connectionURL, String userName, String password) throws SQLException {
		
		connection = DriverManager.getConnection(connectionURL, userName, password);
		closeConnection = true;	
	}
		
	@Override
	public boolean registerNode(Node node) {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public void disableNode(long nodeId) {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public List<Node> getAllNodes() {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public List<Node> getAllNodes(String instanceId) {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public void setNodeAsMaster(Node node) {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public void findMasterNode() {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	@Override
	public void markNodeAsOffline(long nodeId) {
		throw new UnsupportedOperationException("Not supported yet.");
	}
	
}
