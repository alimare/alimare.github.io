package net.alimare.processcontrol.rest;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import net.alimare.processcontrol.ProcessController;
import net.alimare.processcontrol.model.JobRequest;
import net.alimare.processcontrol.service.NodeService;
import net.alimare.processcontrol.types.NodeStatus;
import net.alimare.processcontrol.util.ProcessControlConstant;
import net.sourceforge.stripes.action.*;

/**
 *
 * @author dshurtleff
 */
public class JobSubmitAction
	implements ActionBean
{
	private ActionBeanContext actionBeanContext;
	
	private JobRequest jobRequest;
	
	
	@Override
	public void setContext(ActionBeanContext abc) {
		actionBeanContext = abc;
	}

	@Override
	public ActionBeanContext getContext() {
		return actionBeanContext;
	}			
	
	@HandlesEvent("SumbitJobToController")
	public Resolution  sumbitJobController()
	{
		ProcessController controller = new ProcessController();		
		controller.runJob(jobRequest);
		return new StreamingResolution("text/plain", ProcessControlConstant.ACTION_RESPONSE_JOB_CONTROLLER_RESPONSE);
	}
		
	@HandlesEvent("SumbitJobToNode")
	public Resolution sumbitJobNode()
	{
		try {
			InitialContext context = new InitialContext();			
			NodeService nodeService = (NodeService) context.lookup(NodeService.JEE_JNDI_NAME);
			nodeService.submitJobToNode(jobRequest);
						
			return new StreamingResolution("text/plain", ProcessControlConstant.ACTION_RESPONSE_JOB_SUBMITTED);
		} catch (NamingException ex) {
			Logger.getLogger(JobSubmitAction.class.getName()).log(Level.SEVERE, null, ex);
		}
		return new StreamingResolution("text/plain", NodeStatus.FAULT.toString());		
	}
	
	@HandlesEvent("CheckNode")
	public Resolution checkNode()
	{	
		try {
			InitialContext context = new InitialContext();			
			NodeService nodeService = (NodeService) context.lookup(NodeService.JEE_JNDI_NAME);
			return new StreamingResolution("text/plain", nodeService.getNodeStatus().toString());
		} catch (NamingException ex) {
			Logger.getLogger(JobSubmitAction.class.getName()).log(Level.SEVERE, null, ex);
		}
		return new StreamingResolution("text/plain", NodeStatus.FAULT.toString());
	}

	public JobRequest getJobRequest() {
		return jobRequest;
	}

	public void setJobRequest(JobRequest jobRequest) {
		this.jobRequest = jobRequest;
	}
	
}
