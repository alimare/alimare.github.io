package net.alimare.processcontrol.model;

import java.io.Serializable;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.alimare.processcontrol.AbstractActualJob;
import net.alimare.processcontrol.types.AbstractJobType;
import net.alimare.processcontrol.types.NodeStatus;
import net.alimare.processcontrol.util.MachineStatusUtil;

/**
 *
 * @author dshurtleff
 */
public class Node 
	implements Serializable
{	
	private static final Logger log = Logger.getLogger("net.alimare.processcontrol");
	
	private String nodeIp;	
	private String name;
	private String clusterInstance;
	private NodeStatus nodeStatus = NodeStatus.ONLINE;	
	private Map<String, Object> properties = new HashMap<>();
	private long numberOfJobsRunning;
	private long numberOfCompletedJobs;
	private boolean disabled;
	private AbstractJobType preferJobType;
	private boolean onlyRunJobsOfThePreferedType;
	private int maxRunningJob;
	private boolean masterNode;
	
	private static ThreadPoolExecutor jobPool = new ThreadPoolExecutor(Runtime.getRuntime().availableProcessors(), 
																		Runtime.getRuntime().availableProcessors() * 2, 
																		10, TimeUnit.MINUTES, 
																		new LinkedBlockingDeque<Runnable>());			

	public Node() {
		jobPool.allowCoreThreadTimeOut(true);	
		init();
		
		try {
			nodeIp = InetAddress.getLocalHost().getHostAddress();
			name = InetAddress.getLocalHost().getHostName();
		} catch (UnknownHostException ex) {
			Logger.getLogger(Node.class.getName()).log(Level.SEVERE, null, ex);
		}
	}
	
	private void init()
	{
		properties = MachineStatusUtil.getSystemStatus();
	}
	
	public void refreshAll()
	{
		if (jobPool.getActiveCount() >= Runtime.getRuntime().availableProcessors())
		{
			nodeStatus = NodeStatus.BUZY;
		}
		
		numberOfCompletedJobs = jobPool.getCompletedTaskCount();
		numberOfJobsRunning = jobPool.getActiveCount();
		refreshProperties();
	}
	
	public void refreshProperties()
	{
		properties = MachineStatusUtil.getSystemStatus();
	}	
	
	public void submitJobToRun(JobRequest jobRequest)
	{
		try {
			Class jobClass = Class.forName(jobRequest.getJobClass());
			AbstractActualJob actualJob = (AbstractActualJob) jobClass.newInstance();
			actualJob.setJobContext(jobRequest.getJobContext());
			log.log(Level.FINEST, "Submitted Job: {0}", jobRequest.getJobName());
			jobPool.submit(actualJob);
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException ex) {
			Logger.getLogger(Node.class.getName()).log(Level.SEVERE, null, ex);
		}
	}	
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getClusterInstance() {
		return clusterInstance;
	}

	public void setClusterInstance(String clusterInstance) {
		this.clusterInstance = clusterInstance;
	}

	public NodeStatus getNodeStatus() {
		return nodeStatus;
	}

	public void setNodeStatus(NodeStatus nodeStatus) {
		this.nodeStatus = nodeStatus;
	}

	public Map<String, Object> getProperties() {
		return properties;
	}

	public void setProperties(Map<String, Object> properties) {
		this.properties = properties;
	}

	public long getNumberOfJobsRunning() {
		return numberOfJobsRunning;
	}

	public long getNumberOfCompletedJobs() {
		return numberOfCompletedJobs;
	}

	public boolean isDisabled() {
		return disabled;
	}

	public void setDisabled(boolean disabled) {
		this.disabled = disabled;
	}

	public AbstractJobType getPreferJobType() {
		return preferJobType;
	}

	public void setPreferJobType(AbstractJobType preferJobType) {
		this.preferJobType = preferJobType;
	}

	public int getMaxRunningJob() {
		return maxRunningJob;
	}

	public void setMaxRunningJob(int maxRunningJob) {
		this.maxRunningJob = maxRunningJob;
	}

	public boolean isOnlyRunJobsOfThePreferedType() {
		return onlyRunJobsOfThePreferedType;
	}

	public void setOnlyRunJobsOfThePreferedType(boolean onlyRunJobsOfThePreferedType) {
		this.onlyRunJobsOfThePreferedType = onlyRunJobsOfThePreferedType;
	}

	public String getNodeIp() {
		return nodeIp;
	}

	public void setNodeIp(String nodeIp) {
		this.nodeIp = nodeIp;
	}

	public boolean isMasterNode() {
		return masterNode;
	}

	public void setMasterNode(boolean masterNode) {
		this.masterNode = masterNode;
	}
	
}
