package net.alimare.processcontrol;

import java.util.concurrent.Callable;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.alimare.processcontrol.model.JobContext;
import net.alimare.processcontrol.model.JobRunResult;

/**
 *
 * @author dshurtleff
 */
public abstract class AbstractActualJob 
	implements Callable<JobRunResult>
{
	private static final Logger log = Logger.getLogger("net.alimare.processcontrol");
	
	private JobContext jobContext;

	public AbstractActualJob() {
	}
	
	@Override
	public JobRunResult call() throws Exception {
		log.log(Level.FINEST, "Running Job.");
		JobRunResult jobRunResult =  performJob();
		log.log(Level.FINEST, "Done.");
		return jobRunResult;
	}
	
	protected abstract JobRunResult performJob();
	

	public JobContext getJobContext() {
		return jobContext;
	}

	public void setJobContext(JobContext jobContext) {
		this.jobContext = jobContext;
	}
	
}
