package net.alimare.processcontrol.util;

import java.lang.management.GarbageCollectorMXBean;
import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.management.MemoryPoolMXBean;
import java.lang.management.OperatingSystemMXBean;
import java.lang.management.RuntimeMXBean;
import java.lang.management.ThreadMXBean;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author dshurtleff
 */
public class MachineStatusUtil {
	
	private static int KILO_BYTE = 1024;
	private static int NANO_TO_MILLISECONDS = 1000000;
	
	public static final	RuntimeMXBean RUNTIME_MXBEAN = ManagementFactory.getRuntimeMXBean();
	public static final	OperatingSystemMXBean OPERATING_SYSTEM_MXBEAN = ManagementFactory.getOperatingSystemMXBean();
	public static final	ThreadMXBean THREAD_MXBEAN = ManagementFactory.getThreadMXBean();
	public static final	List<GarbageCollectorMXBean> GARBAGE_COLLECTOR_MXBEANS = ManagementFactory.getGarbageCollectorMXBeans();
	public static final	MemoryMXBean MEMORY_MXBEAN = ManagementFactory.getMemoryMXBean();
	public static final	List<MemoryPoolMXBean> MEMORY_POOL_MXBEANS = ManagementFactory.getMemoryPoolMXBeans();	
			

	public static Map<String, Object> getSystemStatus()
	{
		Map<String, Object> statusMap = new HashMap<>();
		
		statusMap.put("Runtime_Name", RUNTIME_MXBEAN.getName());
		statusMap.put("Start_Time", new Date(RUNTIME_MXBEAN.getStartTime()));
		statusMap.put("Up_Time", RUNTIME_MXBEAN.getUptime() + "ms");
		statusMap.put("Vm_Version", RUNTIME_MXBEAN.getVmVersion());				
		statusMap.put("Processor", OPERATING_SYSTEM_MXBEAN.getAvailableProcessors());
		statusMap.put("OS_Name", OPERATING_SYSTEM_MXBEAN.getName());
		statusMap.put("CPU_Load", OPERATING_SYSTEM_MXBEAN.getSystemLoadAverage());
		statusMap.put("OS_Version", OPERATING_SYSTEM_MXBEAN.getVersion());		
		statusMap.put("Thread_Count", THREAD_MXBEAN.getThreadCount());		
		statusMap.put("Started_Thread_Count", THREAD_MXBEAN.getTotalStartedThreadCount());
		statusMap.put("Current_Thread_CPU_Time", THREAD_MXBEAN.getCurrentThreadCpuTime()/NANO_TO_MILLISECONDS + "ms");
		statusMap.put("Current_Thread_CPU_User_Time", THREAD_MXBEAN.getCurrentThreadUserTime()/NANO_TO_MILLISECONDS + "ms");
		statusMap.put("Heap_Memory_Committed", MEMORY_MXBEAN.getHeapMemoryUsage().getCommitted()/KILO_BYTE+ "KB");
		statusMap.put("Heap_Memory_Init", MEMORY_MXBEAN.getHeapMemoryUsage().getInit()/KILO_BYTE+ "KB");
		statusMap.put("Heap_Memory_Max", MEMORY_MXBEAN.getHeapMemoryUsage().getMax()/KILO_BYTE+ "KB");
		statusMap.put("Heap_Memory_Used", MEMORY_MXBEAN.getHeapMemoryUsage().getUsed()/KILO_BYTE+ "KB");
		statusMap.put("NON_Heap_Memory_Committed", MEMORY_MXBEAN.getNonHeapMemoryUsage().getCommitted()/KILO_BYTE+ "KB");
		statusMap.put("NON_Heap_Memory_Init", MEMORY_MXBEAN.getNonHeapMemoryUsage().getInit()/KILO_BYTE+ "KB");
		statusMap.put("NON_Heap_Memory_Max", MEMORY_MXBEAN.getNonHeapMemoryUsage().getMax()/KILO_BYTE+ "KB");
		statusMap.put("NON_Heap_Memory_Used", MEMORY_MXBEAN.getNonHeapMemoryUsage().getUsed()/KILO_BYTE+ "KB");
		statusMap.put("Pending_Finalization_Count", MEMORY_MXBEAN.getObjectPendingFinalizationCount());
		
		int count = 0;
		for (GarbageCollectorMXBean garbageCollectorMXBean : GARBAGE_COLLECTOR_MXBEANS)
		{
			count++;
			statusMap.put("Garbage_Collector_Name_"+count, garbageCollectorMXBean.getName());
			statusMap.put("Garbage_Collector_Count_"+count, garbageCollectorMXBean.getCollectionCount());
			statusMap.put("Garbage_Collector_Time_"+count, garbageCollectorMXBean.getCollectionTime());			
		}
		
		count = 0;
		for (MemoryPoolMXBean memoryPoolMXBean : MEMORY_POOL_MXBEANS)
		{
			statusMap.put("Memory_Pool_"+count, memoryPoolMXBean.getName());
			statusMap.put("Memory_Pool_Type_"+count, memoryPoolMXBean.getType().name());
			statusMap.put("Memory_Pool_Committed_"+count, memoryPoolMXBean.getUsage().getCommitted()/KILO_BYTE+ "KB");
			statusMap.put("Memory_Pool_Init_"+count, memoryPoolMXBean.getUsage().getInit()/KILO_BYTE+ "KB");
			statusMap.put("Memory_Pool_Max_"+count, memoryPoolMXBean.getUsage().getMax()/KILO_BYTE+ "KB");
			statusMap.put("Memory_Pool_Used_"+count, memoryPoolMXBean.getUsage().getUsed()/KILO_BYTE+ "KB");			
		}		
		
		return statusMap;
	}
	
	
	public List<String> statusPrintList()
	{
		List<String> printList = new ArrayList<>();
		
		Map<String, Object> statusMap = getSystemStatus();
		for (String key : statusMap.keySet())
		{
			printList.add(key + ": " + statusMap.get(key));			
		}
		Collections.sort(printList);		
		return printList;
	}
	
	
}
