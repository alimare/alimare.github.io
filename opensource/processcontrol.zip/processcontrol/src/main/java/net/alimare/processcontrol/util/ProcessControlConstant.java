package net.alimare.processcontrol.util;

/**
 *
 * @author dshurtleff
 */
public class ProcessControlConstant {

	public static final String LOGGER_NAME = "net.alimare.processcontrol";
	
	//System Properties	
	public static final String PROPERTY_MASTER_NODE = "net.alimare.processcontrol.node.master";
	public static final String PROPERTY_NODE_INSTANCE = "net.alimare.processcontrol.node.instance";
	public static final String PROPERTY_NODE_CHECKIN_INTERVAL = "net.alimare.processcontrol.node.checkInInterval";
	public static final String PROPERTY_SERVER_PORT = "net.alimare.processcontrol.server.port";
	public static final String PROPERTY_SERVER_REST_URL = "net.alimare.processcontrol.server.restUrl";
	
	public static final String ACTION_RESPONSE_JOB_SUBMITTED = "Job Submited";
	public static final String ACTION_RESPONSE_JOB_CONTROLLER_RESPONSE = "Job Received";
	
	
}
