package net.alimare.processcontrol.types;

import java.io.Serializable;

/**
 *
 * @author dshurtleff
 */
public enum NodeStatus
	implements Serializable
{
	
	ONLINE,
	OFFLINE,
	BUZY,
	FAULT
	
	
}
